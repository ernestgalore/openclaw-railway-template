"""
FastAPI application entry point
Following 2025 best practices for API design and architecture
"""

from fastapi import FastAPI, Request
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.core.config import settings
from app.core.limiter import limiter
from app.core.logging import setup_logging, get_logger
from app.core.scheduler import start_scheduler, stop_scheduler
from app.api.middleware.cors import setup_cors
from app.api.v1 import (
    health, restaurants, organizations, invitations, roles, invitation_acceptance,
    attendance, tips, wages, dashboard, employees, job_types, policies, scheduling,
    reports, platform_admin, inventory, audit
)
from app.api.v1.users import profile

# Setup logging
setup_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan events - 2025 best practice
    Handles startup and shutdown tasks
    """
    # Startup
    logger.info(
        "Starting application",
        environment=settings.ENVIRONMENT,
        api_url=settings.API_URL
    )
    
    # Start background scheduler for auto clock-out and other periodic tasks
    start_scheduler()
    
    yield
    
    # Shutdown
    logger.info("Shutting down application")
    stop_scheduler()


# Create FastAPI application
app = FastAPI(
    title="Restaurant Management API",
    description="Shift & Wage Management Platform for Restaurants",
    version="0.1.0",
    docs_url="/docs" if settings.ENVIRONMENT == "development" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT == "development" else None,
    lifespan=lifespan,
    redirect_slashes=False,
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)
app.add_middleware(GZipMiddleware, minimum_size=1000)  # Compress responses > 1KB

if settings.ENVIRONMENT == "production":
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["*.railway.app", "api.yourplatform.com"]
    )

# Include routers
app.include_router(
    health.router,
    prefix=settings.API_V1_PREFIX,
    tags=["health"]
)
app.include_router(
    profile.router,
    prefix=f"{settings.API_V1_PREFIX}/users",
    tags=["users"]
)
app.include_router(
    organizations.router,
    prefix=f"{settings.API_V1_PREFIX}/organizations",
    tags=["organizations"]
)
app.include_router(
    restaurants.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["restaurants"]
)
app.include_router(
    invitations.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants/{{restaurant_id}}/invitations",
    tags=["invitations"]
)
app.include_router(
    invitation_acceptance.router,
    prefix=f"{settings.API_V1_PREFIX}/invitations",
    tags=["invitation-acceptance"]
)
app.include_router(
    roles.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["roles"]
)
app.include_router(
    attendance.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants/{{restaurant_id}}/attendance",
    tags=["attendance"]
)
app.include_router(
    tips.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants/{{restaurant_id}}",
    tags=["tips"]
)
app.include_router(
    wages.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["wages"]
)
app.include_router(
    dashboard.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["dashboard"]
)
app.include_router(
    employees.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["employees"]
)
app.include_router(
    job_types.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["job-types"]
)
app.include_router(
    policies.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["policies"]
)
app.include_router(
    scheduling.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["scheduling"]
)
app.include_router(
    reports.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["reports"]
)
app.include_router(
    platform_admin.router,
    prefix=f"{settings.API_V1_PREFIX}/platform-admin",
    tags=["platform-admin"]
)
app.include_router(
    inventory.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["inventory"]
)
app.include_router(
    audit.router,
    prefix=f"{settings.API_V1_PREFIX}/restaurants",
    tags=["audit"]
)

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler for unhandled exceptions"""
    logger.error(
        "Unhandled exception",
        path=request.url.path,
        method=request.method,
        error=str(exc),
        exc_info=True
    )
    
    # Don't expose internal errors in production
    detail = str(exc) if settings.ENVIRONMENT == "development" else "An internal error occurred"
    
    return JSONResponse(
        status_code=500,
        content={"success": False, "detail": detail}
    )


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Restaurant Management API",
        "version": "0.1.0",
        "docs": "/docs" if settings.ENVIRONMENT == "development" else None
    }


# Keep CORS outermost so even unhandled 500 responses include CORS headers.
app = setup_cors(app)


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.ENVIRONMENT == "development",
        log_level=settings.LOG_LEVEL.lower()
    )
