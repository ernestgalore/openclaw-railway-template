#!/usr/bin/env python3
"""
Owner CLI for exercising owner/admin workflows through the real API.

The CLI authenticates through Supabase password auth, stores a local session,
and then calls the backend with the same bearer token the web app uses.
"""

from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import hmac
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


STATE_FILE_ENV = "YUMYUM_OWNER_CLI_STATE_FILE"
DEFAULT_STATE_FILE = Path.home() / ".config" / "yumyum-owner-cli" / "state.json"
DEFAULT_ENV_CANDIDATES = (
    Path("frontend/.env.local"),
    Path("frontend/.env.development.local"),
    Path("/tmp/yumyum-frontend.env"),
)


class CliError(RuntimeError):
    """Raised for user-facing CLI failures."""


class HttpRequestError(RuntimeError):
    """Raised for HTTP failures."""

    def __init__(self, status_code: int, payload: Any):
        self.status_code = status_code
        self.payload = payload
        detail = payload
        if isinstance(payload, dict):
            detail = payload.get("detail") or payload.get("message") or payload
        super().__init__(f"HTTP {status_code}: {detail}")


@dataclass(frozen=True)
class ActionSpec:
    section: str
    name: str
    method: str
    path_template: str
    path_args: tuple[str, ...] = ()
    requires_restaurant: bool = True
    description: str = ""


# These are the common owner/admin actions we want to exercise directly.
# Anything not wrapped here is still reachable through the generic `request` command.
ACTION_SPECS: tuple[ActionSpec, ...] = (
    ActionSpec("profile", "get", "GET", "/api/v1/users/profile", requires_restaurant=False, description="Get the current user's profile."),
    ActionSpec("profile", "update", "PUT", "/api/v1/users/profile", requires_restaurant=False, description="Update the current user's profile settings."),
    ActionSpec("profile", "roles", "GET", "/api/v1/users/me/roles", requires_restaurant=False, description="Get the current user's restaurant roles and recommended route."),
    ActionSpec("organizations", "list", "GET", "/api/v1/organizations", requires_restaurant=False),
    ActionSpec("organizations", "create", "POST", "/api/v1/organizations", requires_restaurant=False),
    ActionSpec("restaurants", "list", "GET", "/api/v1/restaurants", requires_restaurant=False),
    ActionSpec("restaurants", "get", "GET", "/api/v1/restaurants/{restaurant_id}", ("restaurant_id",), False),
    ActionSpec("restaurants", "create", "POST", "/api/v1/restaurants", requires_restaurant=False),
    ActionSpec("restaurants", "update", "PUT", "/api/v1/restaurants/{restaurant_id}", ("restaurant_id",), False),
    ActionSpec("dashboard", "owner-summary", "GET", "/api/v1/restaurants/owner/summary", requires_restaurant=False),
    ActionSpec("dashboard", "metrics", "GET", "/api/v1/restaurants/{restaurant_id}/dashboard/metrics"),
    ActionSpec("dashboard", "alerts", "GET", "/api/v1/restaurants/{restaurant_id}/dashboard/alerts"),
    ActionSpec("roles", "list", "GET", "/api/v1/restaurants/{restaurant_id}/roles"),
    ActionSpec("roles", "assign", "POST", "/api/v1/restaurants/{restaurant_id}/roles/assign"),
    ActionSpec("roles", "revoke", "DELETE", "/api/v1/restaurants/{restaurant_id}/roles/revoke/{user_id}", ("user_id",)),
    ActionSpec("workers", "list", "GET", "/api/v1/restaurants/{restaurant_id}/employees"),
    ActionSpec("workers", "get", "GET", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}", ("employee_id",)),
    ActionSpec("workers", "update", "PUT", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}", ("employee_id",)),
    ActionSpec("workers", "delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}", ("employee_id",)),
    ActionSpec("workers", "list-invites", "GET", "/api/v1/restaurants/{restaurant_id}/invitations", description="List pending worker invitations for the restaurant."),
    ActionSpec("workers", "invite", "POST", "/api/v1/restaurants/{restaurant_id}/invitations"),
    ActionSpec("workers", "resend-invite", "POST", "/api/v1/restaurants/{restaurant_id}/invitations/{invitation_id}/resend", ("invitation_id",)),
    ActionSpec("workers", "cancel-invite", "DELETE", "/api/v1/restaurants/{restaurant_id}/invitations/{invitation_id}", ("invitation_id",)),
    ActionSpec("workers", "add-position", "POST", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}/positions", ("employee_id",)),
    ActionSpec("workers", "update-position", "PUT", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}/positions/{position_id}", ("employee_id", "position_id")),
    ActionSpec("workers", "delete-position", "DELETE", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}/positions/{position_id}", ("employee_id", "position_id")),
    ActionSpec("job-types", "list", "GET", "/api/v1/restaurants/{restaurant_id}/job-types"),
    ActionSpec("job-types", "create", "POST", "/api/v1/restaurants/{restaurant_id}/job-types"),
    ActionSpec("job-types", "update", "PUT", "/api/v1/restaurants/{restaurant_id}/job-types/{job_type_id}", ("job_type_id",)),
    ActionSpec("job-types", "delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/job-types/{job_type_id}", ("job_type_id",)),
    ActionSpec("policies", "get", "GET", "/api/v1/restaurants/{restaurant_id}/policies"),
    ActionSpec("policies", "tip-sessions", "PUT", "/api/v1/restaurants/{restaurant_id}/policies/tip-sessions"),
    ActionSpec("policies", "wage-defaults", "PUT", "/api/v1/restaurants/{restaurant_id}/policies/wage-defaults"),
    ActionSpec("policies", "ai", "PUT", "/api/v1/restaurants/{restaurant_id}/policies/ai"),
    ActionSpec("attendance", "list-events", "GET", "/api/v1/restaurants/{restaurant_id}/attendance/events"),
    ActionSpec("attendance", "get-event", "GET", "/api/v1/restaurants/{restaurant_id}/attendance/events/{event_id}", ("event_id",)),
    ActionSpec("attendance", "update-event", "PUT", "/api/v1/restaurants/{restaurant_id}/attendance/events/{event_id}", ("event_id",)),
    ActionSpec("attendance", "event-history", "GET", "/api/v1/restaurants/{restaurant_id}/attendance/events/{event_id}/history", ("event_id",)),
    ActionSpec("attendance", "manual", "POST", "/api/v1/restaurants/{restaurant_id}/attendance/manual"),
    ActionSpec("attendance", "deviations", "GET", "/api/v1/restaurants/{restaurant_id}/attendance/location-deviations"),
    ActionSpec("attendance", "review-deviation", "PUT", "/api/v1/restaurants/{restaurant_id}/attendance/location-deviations/{deviation_id}/review", ("deviation_id",)),
    ActionSpec("attendance", "auto-clockout", "POST", "/api/v1/restaurants/{restaurant_id}/attendance/auto-clockout", description="Auto clock out overdue shifts for the restaurant."),
    ActionSpec("tips", "sessions", "GET", "/api/v1/restaurants/{restaurant_id}/tips/sessions"),
    ActionSpec("tips", "entry-create", "POST", "/api/v1/restaurants/{restaurant_id}/tips/entries"),
    ActionSpec("tips", "entry-update", "PUT", "/api/v1/restaurants/{restaurant_id}/tips/entries/{entry_id}", ("entry_id",)),
    ActionSpec("tips", "session-entries", "PUT", "/api/v1/restaurants/{restaurant_id}/tips/sessions/{session_id}/entries", ("session_id",)),
    ActionSpec("tips", "allocations", "GET", "/api/v1/restaurants/{restaurant_id}/tips/sessions/{session_id}/allocations", ("session_id",)),
    ActionSpec("tips", "close", "POST", "/api/v1/restaurants/{restaurant_id}/tips/sessions/{session_id}/close", ("session_id",)),
    ActionSpec("tips", "workers-clocked-in", "GET", "/api/v1/restaurants/{restaurant_id}/tips/sessions/{session_id}/workers-clocked-in", ("session_id",)),
    ActionSpec("wages", "calculate", "POST", "/api/v1/restaurants/{restaurant_id}/wages/calculate"),
    ActionSpec(
        "wages",
        "finalize",
        "POST",
        "/api/v1/restaurants/{restaurant_id}/wages/finalize",
        description="Finalize the current payroll draft. Body must include period_start, period_end, expected_run_id, and expected_inputs_hash.",
    ),
    ActionSpec("wages", "reopen", "POST", "/api/v1/restaurants/{restaurant_id}/wages/reopen"),
    ActionSpec("wages", "runs", "GET", "/api/v1/restaurants/{restaurant_id}/wages/runs"),
    ActionSpec("wages", "run", "GET", "/api/v1/restaurants/{restaurant_id}/wages/runs/{run_id}", ("run_id",)),
    ActionSpec("wages", "breakdown", "GET", "/api/v1/restaurants/{restaurant_id}/wages/runs/{run_id}/employee/{employee_id}", ("run_id", "employee_id")),
    ActionSpec("wages", "bonus-create", "POST", "/api/v1/restaurants/{restaurant_id}/wages/bonus"),
    ActionSpec("wages", "bonuses", "GET", "/api/v1/restaurants/{restaurant_id}/wages/bonuses"),
    ActionSpec("wages", "finalization-blockers", "GET", "/api/v1/restaurants/{restaurant_id}/wages/finalization-blockers"),
    ActionSpec("wages", "rules-get", "GET", "/api/v1/restaurants/{restaurant_id}/wages/rules"),
    ActionSpec("wages", "rules-create", "POST", "/api/v1/restaurants/{restaurant_id}/wages/rules"),
    ActionSpec("wages", "rules-update", "PUT", "/api/v1/restaurants/{restaurant_id}/wages/rules/{profile_id}", ("profile_id",)),
    ActionSpec("wages", "pending-approvals", "GET", "/api/v1/restaurants/{restaurant_id}/wages/pending-approvals"),
    ActionSpec("wages", "approve-all", "POST", "/api/v1/restaurants/{restaurant_id}/wages/approve-all"),
    ActionSpec("wages", "approve-edit", "POST", "/api/v1/restaurants/{restaurant_id}/wages/approve-edit/{edit_id}", ("edit_id",)),
    ActionSpec("wages", "reject-edit", "POST", "/api/v1/restaurants/{restaurant_id}/wages/reject-edit/{edit_id}", ("edit_id",)),
    ActionSpec(
        "wages",
        "month-view",
        "GET",
        "/api/v1/restaurants/{restaurant_id}/wages/month-view",
        description="Deprecated compatibility alias. Prefer wages payroll-overview for owner month review.",
    ),
    ActionSpec("wages", "edit-hours", "POST", "/api/v1/restaurants/{restaurant_id}/wages/edit-hours"),
    ActionSpec(
        "wages",
        "payroll-overview",
        "GET",
        "/api/v1/restaurants/{restaurant_id}/wages/payroll-overview",
        description="Canonical owner payroll month review. Returns draft-backed month data, finalized summary, blockers, and drift state.",
    ),
    ActionSpec("holidays", "list", "GET", "/api/v1/restaurants/{restaurant_id}/calendar/holidays"),
    ActionSpec("holidays", "sync", "POST", "/api/v1/restaurants/{restaurant_id}/calendar/holidays/sync", description="Sync system holidays for a given year and country."),
    ActionSpec("holidays", "create", "POST", "/api/v1/restaurants/{restaurant_id}/calendar/holidays"),
    ActionSpec("holidays", "update", "PUT", "/api/v1/restaurants/{restaurant_id}/calendar/holidays/{holiday_id}", ("holiday_id",)),
    ActionSpec("holidays", "delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/calendar/holidays/{holiday_id}", ("holiday_id",)),
    ActionSpec("calendar", "list", "GET", "/api/v1/restaurants/{restaurant_id}/calendar/overrides"),
    ActionSpec("calendar", "create", "POST", "/api/v1/restaurants/{restaurant_id}/calendar/overrides"),
    ActionSpec("calendar", "update", "PUT", "/api/v1/restaurants/{restaurant_id}/calendar/overrides/{override_id}", ("override_id",)),
    ActionSpec("calendar", "delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/calendar/overrides/{override_id}", ("override_id",)),
    ActionSpec("schedules", "templates", "GET", "/api/v1/restaurants/{restaurant_id}/schedules/templates"),
    ActionSpec("schedules", "template-get", "GET", "/api/v1/restaurants/{restaurant_id}/schedules/templates/{template_id}", ("template_id",)),
    ActionSpec("schedules", "template-create", "POST", "/api/v1/restaurants/{restaurant_id}/schedules/templates"),
    ActionSpec("schedules", "template-update", "PUT", "/api/v1/restaurants/{restaurant_id}/schedules/templates/{template_id}", ("template_id",)),
    ActionSpec("schedules", "template-delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/schedules/templates/{template_id}", ("template_id",)),
    ActionSpec("schedules", "list", "GET", "/api/v1/restaurants/{restaurant_id}/schedules"),
    ActionSpec("schedules", "get", "GET", "/api/v1/restaurants/{restaurant_id}/schedules/{schedule_id}", ("schedule_id",)),
    ActionSpec("schedules", "create", "POST", "/api/v1/restaurants/{restaurant_id}/schedules"),
    ActionSpec("schedules", "apply-template", "POST", "/api/v1/restaurants/{restaurant_id}/schedules/{schedule_id}/apply-template", ("schedule_id",)),
    ActionSpec("schedules", "finalize", "PUT", "/api/v1/restaurants/{restaurant_id}/schedules/{schedule_id}/finalize", ("schedule_id",)),
    ActionSpec("schedules", "assign", "POST", "/api/v1/restaurants/{restaurant_id}/schedules/{schedule_id}/assignments", ("schedule_id",)),
    ActionSpec("schedules", "move-assignment", "PUT", "/api/v1/restaurants/{restaurant_id}/assignments/{assignment_id}", ("assignment_id",)),
    ActionSpec("schedules", "remove-assignment", "DELETE", "/api/v1/restaurants/{restaurant_id}/assignments/{assignment_id}", ("assignment_id",)),
    ActionSpec("schedules", "preferences-get", "GET", "/api/v1/restaurants/{restaurant_id}/preferences"),
    ActionSpec("schedules", "preferences-update", "PUT", "/api/v1/restaurants/{restaurant_id}/preferences"),
    ActionSpec("schedules", "compatibility-get", "GET", "/api/v1/restaurants/{restaurant_id}/employees/{employee_id}/compatibility", ("employee_id",)),
    ActionSpec("schedules", "compatibility-update", "PUT", "/api/v1/restaurants/{restaurant_id}/compatibility"),
    ActionSpec("inventory", "categories", "GET", "/api/v1/restaurants/{restaurant_id}/inventory/categories"),
    ActionSpec("inventory", "category-create", "POST", "/api/v1/restaurants/{restaurant_id}/inventory/categories"),
    ActionSpec("inventory", "suppliers", "GET", "/api/v1/restaurants/{restaurant_id}/inventory/suppliers"),
    ActionSpec("inventory", "supplier-create", "POST", "/api/v1/restaurants/{restaurant_id}/inventory/suppliers"),
    ActionSpec("inventory", "supplier-update", "PUT", "/api/v1/restaurants/{restaurant_id}/inventory/suppliers/{supplier_id}", ("supplier_id",)),
    ActionSpec("inventory", "supplier-delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/inventory/suppliers/{supplier_id}", ("supplier_id",)),
    ActionSpec("inventory", "items", "GET", "/api/v1/restaurants/{restaurant_id}/inventory/items"),
    ActionSpec("inventory", "item-create", "POST", "/api/v1/restaurants/{restaurant_id}/inventory/items"),
    ActionSpec("inventory", "item-update", "PUT", "/api/v1/restaurants/{restaurant_id}/inventory/items/{item_id}", ("item_id",)),
    ActionSpec("inventory", "item-delete", "DELETE", "/api/v1/restaurants/{restaurant_id}/inventory/items/{item_id}", ("item_id",)),
    ActionSpec("inventory", "restocks", "GET", "/api/v1/restaurants/{restaurant_id}/inventory/restock-requests"),
    ActionSpec("inventory", "restock-create", "POST", "/api/v1/restaurants/{restaurant_id}/inventory/restock-requests"),
    ActionSpec("inventory", "restock-status", "PUT", "/api/v1/restaurants/{restaurant_id}/inventory/restock-requests/{restock_id}/status", ("restock_id",)),
    ActionSpec("inventory", "supplier-list", "GET", "/api/v1/restaurants/{restaurant_id}/inventory/restock-requests/{restock_id}/supplier-list", ("restock_id",)),
    ActionSpec("inventory", "counts", "GET", "/api/v1/restaurants/{restaurant_id}/inventory/counts"),
    ActionSpec("inventory", "count-create", "POST", "/api/v1/restaurants/{restaurant_id}/inventory/counts"),
    ActionSpec("reports", "monthly", "GET", "/api/v1/restaurants/{restaurant_id}/reports/wages/monthly"),
    ActionSpec("reports", "clear-cache", "DELETE", "/api/v1/restaurants/{restaurant_id}/reports/cache"),
    ActionSpec("reports", "cache-stats", "GET", "/api/v1/restaurants/cache/stats", requires_restaurant=False, description="Show report cache statistics for debugging and smoke tests."),
    ActionSpec("audit", "list", "GET", "/api/v1/restaurants/{restaurant_id}/audit/events"),
    ActionSpec("audit", "get", "GET", "/api/v1/restaurants/{restaurant_id}/audit/events/{event_id}", ("event_id",)),
    ActionSpec("audit", "entity-types", "GET", "/api/v1/restaurants/{restaurant_id}/audit/entity-types"),
)

ACTION_INDEX = {(spec.section, spec.name): spec for spec in ACTION_SPECS}


def get_state_file() -> Path:
    path = os.environ.get(STATE_FILE_ENV)
    return Path(path).expanduser() if path else DEFAULT_STATE_FILE


def load_state(path: Path | None = None) -> dict[str, Any]:
    target = path or get_state_file()
    if not target.exists():
        return {"config": {}, "session": {}, "context": {}}
    try:
        return json.loads(target.read_text())
    except json.JSONDecodeError as exc:
        raise CliError(f"State file is invalid JSON: {target}") from exc


def save_state(state: dict[str, Any], path: Path | None = None) -> None:
    target = path or get_state_file()
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(target.parent, 0o700)
    except OSError:
        pass
    target.write_text(json.dumps(state, indent=2, sort_keys=True))
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass


def parse_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        raise CliError(f"Env file not found: {path}")
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip("'").strip('"')
    return values


def discover_env_file() -> Path | None:
    for candidate in DEFAULT_ENV_CANDIDATES:
        if candidate.exists():
            return candidate
    return None


def build_env_source(env_file: str | None = None) -> dict[str, str]:
    source = dict(os.environ)
    chosen_file = Path(env_file).expanduser() if env_file else discover_env_file()
    if chosen_file and chosen_file.exists():
        source.update(parse_env_file(chosen_file))
        source["_OWNER_CLI_ENV_FILE"] = str(chosen_file)
    return source


def resolve_config(
    state: dict[str, Any],
    env_file: str | None = None,
    cli_overrides: dict[str, str | None] | None = None,
    require_supabase: bool = False,
) -> dict[str, str]:
    env_source = build_env_source(env_file)
    persisted = state.get("config", {})
    overrides = cli_overrides or {}

    config = {
        "api_url": overrides.get("api_url")
        or env_source.get("OWNER_CLI_API_URL")
        or env_source.get("NEXT_PUBLIC_API_URL")
        or persisted.get("api_url"),
        "supabase_url": overrides.get("supabase_url")
        or env_source.get("OWNER_CLI_SUPABASE_URL")
        or env_source.get("NEXT_PUBLIC_SUPABASE_URL")
        or persisted.get("supabase_url"),
        "supabase_anon_key": overrides.get("supabase_anon_key")
        or env_source.get("OWNER_CLI_SUPABASE_ANON_KEY")
        or env_source.get("NEXT_PUBLIC_SUPABASE_ANON_KEY")
        or persisted.get("supabase_anon_key"),
        "supabase_service_role_key": overrides.get("supabase_service_role_key")
        or env_source.get("OWNER_CLI_SUPABASE_SERVICE_ROLE_KEY")
        or env_source.get("SUPABASE_SERVICE_ROLE_KEY"),
        "supabase_jwt_secret": overrides.get("supabase_jwt_secret")
        or env_source.get("OWNER_CLI_SUPABASE_JWT_SECRET")
        or env_source.get("SUPABASE_JWT_SECRET"),
    }

    if not config["api_url"]:
        raise CliError(
            "Missing API URL. Set NEXT_PUBLIC_API_URL in the environment, use --env-file, "
            "or import config with `config import-env`."
        )

    if require_supabase and (not config["supabase_url"] or not config["supabase_anon_key"]):
        raise CliError(
            "Missing Supabase config. Set NEXT_PUBLIC_SUPABASE_URL and "
            "NEXT_PUBLIC_SUPABASE_ANON_KEY, or use --env-file."
        )

    return config


def parse_loose_value(raw: str) -> Any:
    value = raw.strip()
    if value.startswith("@"):
        file_path = Path(value[1:]).expanduser()
        return json.loads(file_path.read_text())

    if value.startswith("{") or value.startswith("["):
        return json.loads(value)

    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None

    if re.fullmatch(r"-?\d+", value):
        return int(value)
    if re.fullmatch(r"-?\d+\.\d+", value):
        return float(value)

    return value


def parse_pairs(pairs: Iterable[str]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for pair in pairs:
        if "=" not in pair:
            raise CliError(f"Expected key=value pair, received: {pair}")
        key, raw_value = pair.split("=", 1)
        parsed[key] = parse_loose_value(raw_value)
    return parsed


def merge_body_inputs(args: argparse.Namespace) -> dict[str, Any] | None:
    body: dict[str, Any] = {}

    if getattr(args, "json_body", None):
        body.update(json.loads(args.json_body))

    if getattr(args, "json_file", None):
        body.update(json.loads(Path(args.json_file).expanduser().read_text()))

    field_pairs = getattr(args, "field", None) or []
    body.update(parse_pairs(field_pairs))

    return body or None


def build_query_params(args: argparse.Namespace) -> dict[str, Any]:
    return parse_pairs(getattr(args, "query", None) or [])


def normalize_path(path: str, restaurant_id: str | None = None) -> str:
    normalized = path if path.startswith("/") else f"/{path}"
    if restaurant_id:
        normalized = normalized.replace(":restaurant_id", restaurant_id)
        normalized = normalized.replace(":restaurant", restaurant_id)
        normalized = normalized.replace("{restaurant_id}", restaurant_id)
    return normalized


def path_requires_restaurant_context(path: str) -> bool:
    return any(token in path for token in (":restaurant_id", ":restaurant", "{restaurant_id}"))


def resolve_restaurant_id(args: argparse.Namespace, state: dict[str, Any], required: bool) -> str | None:
    restaurant_id = getattr(args, "restaurant_id", None) or state.get("context", {}).get("restaurant_id")
    if required and not restaurant_id:
        raise CliError(
            "No restaurant selected. Use --restaurant-id or `restaurants select RESTAURANT_ID`."
        )
    return restaurant_id


def build_path(spec: ActionSpec, args: argparse.Namespace, restaurant_id: str | None) -> str:
    substitutions = {}
    if "{restaurant_id}" in spec.path_template:
        substitutions["restaurant_id"] = restaurant_id
    for name in spec.path_args:
        substitutions[name] = getattr(args, name)
    try:
        return spec.path_template.format(**substitutions)
    except KeyError as exc:
        raise CliError(f"Missing path value for {exc.args[0]}") from exc


def format_query_string(params: dict[str, Any]) -> str:
    if not params:
        return ""
    query = urllib.parse.urlencode(
        [(key, stringify_query_value(value)) for key, value in params.items()],
        doseq=True,
    )
    return f"?{query}" if query else ""


def stringify_query_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value)
    return str(value)


def decode_response_body(body: bytes, headers: dict[str, str]) -> Any:
    content_type = headers.get("Content-Type", headers.get("content-type", "")).lower()
    if not body:
        return None
    if "application/json" in content_type:
        return json.loads(body.decode())
    try:
        return json.loads(body.decode())
    except Exception:
        return body.decode(errors="replace")


def raw_http_request(
    url: str,
    method: str,
    headers: dict[str, str],
    body: dict[str, Any] | None = None,
) -> tuple[int, dict[str, str], bytes]:
    payload = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(url=url, method=method.upper(), headers=headers, data=payload)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return response.status, dict(response.headers), response.read()
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers), exc.read()


def session_is_expired(session: dict[str, Any]) -> bool:
    expires_at = session.get("expires_at")
    if not session.get("access_token") or not expires_at:
        return True
    return int(expires_at) <= int(time.time()) + 30


def persist_config(state: dict[str, Any], config: dict[str, str]) -> None:
    state.setdefault("config", {})
    state["config"].update(
        {
            "api_url": config["api_url"],
            "supabase_url": config.get("supabase_url"),
            "supabase_anon_key": config.get("supabase_anon_key"),
        }
    )


def clear_context_if_user_changed(state: dict[str, Any], next_user_id: str | None) -> None:
    current_user_id = (state.get("session") or {}).get("user", {}).get("id")
    if current_user_id and next_user_id and current_user_id != next_user_id:
        state["context"] = {}


def maybe_store_single_restaurant_context(
    state: dict[str, Any],
    roles_response: dict[str, Any] | None,
) -> str | None:
    roles_data = (roles_response or {}).get("data")
    if not isinstance(roles_data, dict):
        return None

    restaurants = roles_data.get("restaurants")
    if not isinstance(restaurants, list) or len(restaurants) != 1:
        return None

    restaurant_id = restaurants[0].get("id")
    if not restaurant_id:
        return None

    state.setdefault("context", {})
    state["context"]["restaurant_id"] = restaurant_id
    return restaurant_id


def supabase_token_request(config: dict[str, str], grant_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    url = f"{config['supabase_url'].rstrip('/')}/auth/v1/token?grant_type={grant_type}"
    headers = {
        "apikey": config["supabase_anon_key"],
        "Authorization": f"Bearer {config['supabase_anon_key']}",
        "Content-Type": "application/json",
    }
    status, response_headers, raw_body = raw_http_request(url, "POST", headers, payload)
    body = decode_response_body(raw_body, response_headers)
    if status >= 400:
        raise HttpRequestError(status, body)
    if not isinstance(body, dict):
        raise CliError("Supabase auth returned an unexpected response.")
    return body


def session_from_auth_response(response: dict[str, Any]) -> dict[str, Any]:
    expires_in = int(response.get("expires_in") or 3600)
    expires_at = int(time.time()) + expires_in
    return {
        "access_token": response.get("access_token"),
        "refresh_token": response.get("refresh_token"),
        "expires_at": expires_at,
        "token_type": response.get("token_type", "bearer"),
        "user": response.get("user") or {},
    }


def b64url_encode(raw: bytes) -> bytes:
    return base64.urlsafe_b64encode(raw).rstrip(b"=")


def encode_hs256_jwt(payload: dict[str, Any], secret: str) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    encoded_header = b64url_encode(json.dumps(header, separators=(",", ":"), sort_keys=True).encode())
    encoded_payload = b64url_encode(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    signing_input = b".".join((encoded_header, encoded_payload))
    signature = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    encoded_signature = b64url_encode(signature)
    return b".".join((encoded_header, encoded_payload, encoded_signature)).decode()


def list_supabase_admin_users(config: dict[str, str]) -> list[dict[str, Any]]:
    if not config.get("supabase_url"):
        raise CliError("Missing Supabase URL. Provide --supabase-url or load backend/frontend env config first.")
    if not config.get("supabase_service_role_key"):
        raise CliError(
            "Missing Supabase service role key. Run the command through `railway run`, "
            "or set SUPABASE_SERVICE_ROLE_KEY / OWNER_CLI_SUPABASE_SERVICE_ROLE_KEY."
        )

    url = f"{config['supabase_url'].rstrip('/')}/auth/v1/admin/users?page=1&per_page=1000"
    headers = {
        "apikey": config["supabase_service_role_key"],
        "Authorization": f"Bearer {config['supabase_service_role_key']}",
    }
    status, response_headers, raw_body = raw_http_request(url, "GET", headers)
    body = decode_response_body(raw_body, response_headers)
    if status >= 400:
        raise HttpRequestError(status, body)
    if not isinstance(body, dict) or not isinstance(body.get("users"), list):
        raise CliError("Supabase admin users endpoint returned an unexpected response.")
    return body["users"]


def resolve_assumed_user(
    config: dict[str, str],
    *,
    user_id: str | None,
    email: str | None,
    full_name: str | None,
) -> dict[str, Any]:
    if user_id:
        return {
            "id": user_id,
            "email": email,
            "user_metadata": {"full_name": full_name} if full_name else {},
        }

    if not email:
        raise CliError("Provide --user-id or --email.")

    normalized_email = email.strip().lower()
    users = list_supabase_admin_users(config)
    matches = [user for user in users if (user.get("email") or "").strip().lower() == normalized_email]
    if not matches:
        raise CliError(f"No Supabase user found for email {email}.")
    if len(matches) > 1:
        raise CliError(f"Multiple Supabase users matched {email}. Use --user-id explicitly.")

    user = matches[0]
    if full_name and isinstance(user.get("user_metadata"), dict):
        user["user_metadata"] = {**user["user_metadata"], "full_name": full_name}
    return user


def build_assumed_session(user: dict[str, Any], jwt_secret: str, expires_in: int) -> dict[str, Any]:
    now = int(time.time())
    expires_at = now + expires_in
    email = user.get("email")
    payload = {
        "iss": "owner-cli",
        "sub": user["id"],
        "aud": "authenticated",
        "role": "authenticated",
        "exp": expires_at,
        "iat": now,
        "email": email,
        "phone": user.get("phone") or "",
        "app_metadata": user.get("app_metadata") or {"provider": "owner-cli", "providers": ["owner-cli"]},
        "user_metadata": user.get("user_metadata") or {},
        "aal": "aal1",
        "amr": [{"method": "owner_cli_assume", "timestamp": now}],
        "is_anonymous": False,
    }
    return {
        "access_token": encode_hs256_jwt(payload, jwt_secret),
        "refresh_token": None,
        "expires_at": expires_at,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "email": email,
            "user_metadata": user.get("user_metadata") or {},
            "app_metadata": user.get("app_metadata") or {},
        },
    }


def refresh_session(state: dict[str, Any], config: dict[str, str]) -> dict[str, Any]:
    refresh_token = state.get("session", {}).get("refresh_token")
    if not refresh_token:
        raise CliError(
            "No refresh token available. If this is an assumed session, run `auth assume` again. "
            "Otherwise run `auth login` again."
        )
    response = supabase_token_request(
        config,
        "refresh_token",
        {"refresh_token": refresh_token},
    )
    state["session"] = session_from_auth_response(response)
    save_state(state)
    return state["session"]


def ensure_session(state: dict[str, Any], config: dict[str, str]) -> dict[str, Any]:
    session = state.get("session") or {}
    if not session.get("access_token"):
        raise CliError("Not logged in. Run `auth login` first.")
    if session_is_expired(session):
        session = refresh_session(state, config)
    return session


def authenticated_request(
    state: dict[str, Any],
    config: dict[str, str],
    method: str,
    path: str,
    query: dict[str, Any] | None = None,
    body: dict[str, Any] | None = None,
    raw: bool = False,
) -> Any:
    session = ensure_session(state, config)
    url = f"{config['api_url'].rstrip('/')}{path}{format_query_string(query or {})}"
    headers = {
        "Authorization": f"Bearer {session['access_token']}",
    }
    if body is not None:
        headers["Content-Type"] = "application/json"

    status, response_headers, raw_body = raw_http_request(url, method, headers, body)
    if status == 401:
        session = refresh_session(state, config)
        headers["Authorization"] = f"Bearer {session['access_token']}"
        status, response_headers, raw_body = raw_http_request(url, method, headers, body)

    if raw:
        if status >= 400:
            raise HttpRequestError(status, decode_response_body(raw_body, response_headers))
        return status, response_headers, raw_body

    decoded = decode_response_body(raw_body, response_headers)
    if status >= 400:
        raise HttpRequestError(status, decoded)
    return decoded


def print_result(result: Any) -> None:
    if result is None:
        return
    if isinstance(result, (dict, list)):
        print(json.dumps(result, indent=2, sort_keys=False, ensure_ascii=False))
        return
    print(result)


def handle_config_import_env(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(
        state,
        env_file=args.env_file,
        cli_overrides={
            "api_url": args.api_url,
            "supabase_url": args.supabase_url,
            "supabase_anon_key": args.supabase_anon_key,
        },
        require_supabase=True,
    )
    persist_config(state, config)
    save_state(state)
    print_result(
        {
            "saved": True,
            "config": {
                "api_url": config["api_url"],
                "supabase_url": config["supabase_url"],
                "supabase_anon_key": redact_secret(config["supabase_anon_key"]),
            },
        }
    )


def handle_config_show(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(
        state,
        env_file=args.env_file,
        cli_overrides={
            "api_url": args.api_url,
            "supabase_url": args.supabase_url,
            "supabase_anon_key": args.supabase_anon_key,
        },
        require_supabase=False,
    )
    output = {
        "api_url": config["api_url"],
        "supabase_url": config.get("supabase_url"),
        "supabase_anon_key": redact_secret(config.get("supabase_anon_key")),
        "env_file": build_env_source(args.env_file).get("_OWNER_CLI_ENV_FILE"),
        "current_restaurant_id": state.get("context", {}).get("restaurant_id"),
        "logged_in": bool(state.get("session", {}).get("access_token")),
    }
    print_result(output)


def redact_secret(value: str | None) -> str | None:
    if not value:
        return value
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def handle_auth_login(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(
        state,
        env_file=args.env_file,
        cli_overrides={
            "api_url": args.api_url,
            "supabase_url": args.supabase_url,
            "supabase_anon_key": args.supabase_anon_key,
        },
        require_supabase=True,
    )
    email = args.email or input("Email: ").strip()
    password = args.password or getpass.getpass("Password: ")
    response = supabase_token_request(
        config,
        "password",
        {"email": email, "password": password},
    )
    clear_context_if_user_changed(state, (response.get("user") or {}).get("id"))
    state["session"] = session_from_auth_response(response)
    persist_config(state, config)
    save_state(state)

    profile = authenticated_request(state, config, "GET", "/api/v1/users/profile")
    roles = authenticated_request(state, config, "GET", "/api/v1/users/me/roles")
    selected_restaurant_id = maybe_store_single_restaurant_context(state, roles)
    save_state(state)

    result = {
        "logged_in": True,
        "profile": profile,
        "roles": roles,
    }
    if selected_restaurant_id:
        result["selected_restaurant_id"] = selected_restaurant_id
    print_result(result)


def handle_auth_assume(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(
        state,
        env_file=args.env_file,
        cli_overrides={
            "api_url": args.api_url,
            "supabase_url": args.supabase_url,
            "supabase_anon_key": args.supabase_anon_key,
            "supabase_service_role_key": args.supabase_service_role_key,
            "supabase_jwt_secret": args.supabase_jwt_secret,
        },
        require_supabase=False,
    )
    if not config.get("supabase_jwt_secret"):
        raise CliError(
            "Missing Supabase JWT secret. Run the command through `railway run`, "
            "or set SUPABASE_JWT_SECRET / OWNER_CLI_SUPABASE_JWT_SECRET."
        )

    assumed_user = resolve_assumed_user(
        config,
        user_id=args.user_id,
        email=args.email,
        full_name=args.full_name,
    )
    clear_context_if_user_changed(state, assumed_user.get("id"))
    state["session"] = build_assumed_session(
        assumed_user,
        config["supabase_jwt_secret"],
        max(int(args.expires_in), 60),
    )
    persist_config(state, config)
    save_state(state)

    profile = authenticated_request(state, config, "GET", "/api/v1/users/profile")
    roles = authenticated_request(state, config, "GET", "/api/v1/users/me/roles")
    selected_restaurant_id = maybe_store_single_restaurant_context(state, roles)
    save_state(state)

    result = {
        "assumed": True,
        "profile": profile,
        "roles": roles,
    }
    if selected_restaurant_id:
        result["selected_restaurant_id"] = selected_restaurant_id
    print_result(result)


def handle_auth_refresh(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=True)
    session = refresh_session(state, config)
    print_result({"refreshed": True, "expires_at": session.get("expires_at")})


def handle_auth_logout(args: argparse.Namespace) -> None:
    state = load_state()
    state["session"] = {}
    save_state(state)
    print_result({"logged_out": True})


def handle_auth_whoami(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    profile = authenticated_request(state, config, "GET", "/api/v1/users/profile")
    roles = authenticated_request(state, config, "GET", "/api/v1/users/me/roles")
    print_result({"profile": profile, "roles": roles})


def handle_restaurant_select(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant = authenticated_request(state, config, "GET", f"/api/v1/restaurants/{args.restaurant_id}")
    state.setdefault("context", {})
    state["context"]["restaurant_id"] = args.restaurant_id
    save_state(state)
    print_result(
        {
            "selected_restaurant_id": args.restaurant_id,
            "restaurant": restaurant,
        }
    )


def handle_restaurant_current(args: argparse.Namespace) -> None:
    state = load_state()
    restaurant_id = state.get("context", {}).get("restaurant_id")
    if not restaurant_id:
        raise CliError("No restaurant selected.")
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant = authenticated_request(state, config, "GET", f"/api/v1/restaurants/{restaurant_id}")
    print_result({"restaurant_id": restaurant_id, "restaurant": restaurant})


def handle_operations_list(args: argparse.Namespace) -> None:
    rows = []
    for spec in ACTION_SPECS:
        if args.section and spec.section != args.section:
            continue
        rows.append(
            {
                "section": spec.section,
                "name": spec.name,
                "method": spec.method,
                "path": spec.path_template,
                "requires_restaurant": spec.requires_restaurant,
                "description": spec.description or None,
            }
        )
    print_result(rows)


def _shape_output_bytes(raw_body: bytes, headers: dict[str, str]) -> bytes:
    """Re-encode JSON responses with ensure_ascii=False so saved files are readable
    in Hebrew/Unicode; leave binary payloads (xlsx, csv, pdf, etc.) untouched."""
    content_type = (headers.get("Content-Type") or headers.get("content-type") or "").lower()
    if "application/json" not in content_type:
        return raw_body
    try:
        payload = json.loads(raw_body.decode())
    except Exception:
        return raw_body
    return json.dumps(payload, indent=2, ensure_ascii=False).encode()


def _is_uuid(value: str) -> bool:
    try:
        uuid.UUID(value)
        return True
    except (ValueError, AttributeError, TypeError):
        return False


def resolve_employee(
    identifier: str,
    state: dict[str, Any],
    config: dict[str, str],
    restaurant_id: str,
) -> dict[str, Any]:
    """Resolve a UUID or a (partial) employee full name to an employee record.

    Match order for non-UUID identifiers:
      1. exact full-name (case sensitive)
      2. case-insensitive exact full-name
      3. case-insensitive substring on full-name
    Raises CliError on 0 matches or ambiguity at any tier.
    """
    if not identifier:
        raise CliError("Empty employee identifier.")

    if _is_uuid(identifier):
        response = authenticated_request(
            state,
            config,
            "GET",
            f"/api/v1/restaurants/{restaurant_id}/employees/{identifier}",
        )
        data = (response or {}).get("data") if isinstance(response, dict) else None
        if not data:
            raise CliError(f"Employee {identifier} not found in restaurant {restaurant_id}.")
        return data

    listing = authenticated_request(
        state,
        config,
        "GET",
        f"/api/v1/restaurants/{restaurant_id}/employees",
    )
    employees = (listing or {}).get("data") if isinstance(listing, dict) else None
    if not isinstance(employees, list):
        raise CliError("Unexpected response from employees list.")

    needle = identifier.strip()
    needle_lower = needle.lower()

    exact = [e for e in employees if (e.get("fullName") or "") == needle]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        raise CliError(_ambiguity_message(identifier, exact))

    ci_exact = [e for e in employees if (e.get("fullName") or "").lower() == needle_lower]
    if len(ci_exact) == 1:
        return ci_exact[0]
    if len(ci_exact) > 1:
        raise CliError(_ambiguity_message(identifier, ci_exact))

    substring = [e for e in employees if needle_lower in (e.get("fullName") or "").lower()]
    if len(substring) == 1:
        return substring[0]
    if len(substring) > 1:
        raise CliError(_ambiguity_message(identifier, substring))

    raise CliError(
        f"No employee matched {identifier!r} in restaurant {restaurant_id}. "
        "Run `workers list` to see available names."
    )


def _ambiguity_message(identifier: str, matches: list[dict[str, Any]]) -> str:
    shortlist = [
        {"id": m.get("id"), "fullName": m.get("fullName"), "status": m.get("status")}
        for m in matches[:10]
    ]
    return (
        f"Multiple employees matched {identifier!r}. Narrow the name or pass --employee with the exact name. "
        f"Candidates: {json.dumps(shortlist, ensure_ascii=False)}"
    )


def handle_workers_find(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant_id = resolve_restaurant_id(args, state, required=True)
    result = resolve_employee(args.identifier, state, config, restaurant_id)
    print_result(result)


def resolve_invitation(
    identifier: str,
    state: dict[str, Any],
    config: dict[str, str],
    restaurant_id: str,
) -> dict[str, Any]:
    """Resolve a UUID, email, or (partial) full name to a pending invitation record."""
    if not identifier:
        raise CliError("Empty invitation identifier.")

    if _is_uuid(identifier):
        listing = authenticated_request(
            state,
            config,
            "GET",
            f"/api/v1/restaurants/{restaurant_id}/invitations",
        )
        invites = (listing or {}).get("data") if isinstance(listing, dict) else None
        if isinstance(invites, list):
            for inv in invites:
                if inv.get("id") == identifier:
                    return inv
        raise CliError(f"Invitation {identifier} not found in restaurant {restaurant_id}.")

    listing = authenticated_request(
        state,
        config,
        "GET",
        f"/api/v1/restaurants/{restaurant_id}/invitations",
    )
    invites = (listing or {}).get("data") if isinstance(listing, dict) else None
    if not isinstance(invites, list):
        raise CliError("Unexpected response from invitations list.")

    needle = identifier.strip()
    needle_lower = needle.lower()

    email_matches = [i for i in invites if (i.get("email") or "").lower() == needle_lower]
    if len(email_matches) == 1:
        return email_matches[0]
    if len(email_matches) > 1:
        raise CliError(_invite_ambiguity_message(identifier, email_matches))

    exact = [i for i in invites if (i.get("fullName") or "") == needle]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        raise CliError(_invite_ambiguity_message(identifier, exact))

    ci_exact = [i for i in invites if (i.get("fullName") or "").lower() == needle_lower]
    if len(ci_exact) == 1:
        return ci_exact[0]
    if len(ci_exact) > 1:
        raise CliError(_invite_ambiguity_message(identifier, ci_exact))

    substring = [i for i in invites if needle_lower in (i.get("fullName") or "").lower()]
    if len(substring) == 1:
        return substring[0]
    if len(substring) > 1:
        raise CliError(_invite_ambiguity_message(identifier, substring))

    raise CliError(
        f"No invitation matched {identifier!r} in restaurant {restaurant_id}. "
        "Run `workers list-invites` to see pending invitations."
    )


def _invite_ambiguity_message(identifier: str, matches: list[dict[str, Any]]) -> str:
    shortlist = [
        {"id": m.get("id"), "fullName": m.get("fullName"), "email": m.get("email")}
        for m in matches[:10]
    ]
    return (
        f"Multiple invitations matched {identifier!r}. Narrow the name or pass --invitation with the exact value. "
        f"Candidates: {json.dumps(shortlist, ensure_ascii=False)}"
    )


def handle_workers_find_invite(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant_id = resolve_restaurant_id(args, state, required=True)
    result = resolve_invitation(args.identifier, state, config, restaurant_id)
    print_result(result)


def handle_daily_summary(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant_id = resolve_restaurant_id(args, state, required=True)

    day_start = f"{args.date}T00:00:00Z"
    day_end = f"{args.date}T23:59:59Z"

    attendance = authenticated_request(
        state,
        config,
        "GET",
        f"/api/v1/restaurants/{restaurant_id}/attendance/events",
        query={"start_date": day_start, "end_date": day_end, "limit": 200},
    )
    events = (attendance or {}).get("events") if isinstance(attendance, dict) else None
    events = events or []

    clock_in = sum(1 for e in events if e.get("type") == "in")
    clock_out = sum(1 for e in events if e.get("type") == "out")
    manual = sum(1 for e in events if (e.get("method") or "") == "manual")
    auto = sum(
        1 for e in events
        if "AUTO_CLOCKOUT" in (e.get("flag_types") or [])
    )
    flagged = [
        {
            "id": e.get("id"),
            "employee": (e.get("employee") or {}).get("full_name"),
            "type": e.get("type"),
            "ts_local": e.get("ts_local"),
            "flag_types": e.get("flag_types"),
        }
        for e in events
        if e.get("is_flagged")
    ]

    tips_resp = authenticated_request(
        state,
        config,
        "GET",
        f"/api/v1/restaurants/{restaurant_id}/tips/sessions",
        query={"session_date": args.date},
    )
    sessions = (tips_resp or {}).get("sessions") if isinstance(tips_resp, dict) else None
    sessions = sessions or []

    tip_sessions = [
        {
            "id": s.get("id"),
            "session_index": s.get("session_index"),
            "name": s.get("session_name"),
            "status": s.get("status"),
            "cash_total": s.get("cash_total"),
            "credit_total": s.get("credit_total"),
            "has_cash_entry": bool(s.get("cash_entry_id")),
            "has_credit_entry": bool(s.get("credit_entry_id")),
            "closed_at": s.get("closed_at"),
        }
        for s in sessions
    ]

    print_result({
        "date": args.date,
        "restaurant_id": restaurant_id,
        "attendance": {
            "total_events": len(events),
            "clock_in_events": clock_in,
            "clock_out_events": clock_out,
            "manual_entries": manual,
            "auto_clockouts": auto,
            "flagged": flagged,
        },
        "tips": {
            "sessions": tip_sessions,
        },
    })


def handle_wages_finalize_preview(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant_id = resolve_restaurant_id(args, state, required=True)

    overview = authenticated_request(
        state,
        config,
        "GET",
        f"/api/v1/restaurants/{restaurant_id}/wages/payroll-overview",
        query={"period_start": args.period_start, "period_end": args.period_end},
    )
    if not isinstance(overview, dict):
        raise CliError("Unexpected response from payroll-overview.")

    draft_run = overview.get("draft_run") or {}
    draft_summary = overview.get("draft_summary") or {}
    blockers = overview.get("finalization_blockers") or []
    drift = overview.get("drift") or {}
    finalized_run = overview.get("finalized_run")

    ready = (not blockers) and (not drift.get("has_drift")) and bool(draft_run.get("id"))

    preview = {
        "period": {"start": args.period_start, "end": args.period_end},
        "draft_run": {
            "id": draft_run.get("id"),
            "version": draft_run.get("version"),
            "inputs_hash": draft_run.get("inputs_hash"),
            "computed_at": draft_run.get("computed_at"),
            "status": draft_run.get("status"),
        },
        "totals": draft_summary,
        "finalized_run_id": (finalized_run or {}).get("id"),
        "blockers": blockers,
        "drift": drift,
        "ready_to_finalize": ready,
        "finalize_command_hint": (
            f"scripts/owner-cli wages finalize "
            f"--field period_start={args.period_start} "
            f"--field period_end={args.period_end} "
            f"--field expected_run_id={draft_run.get('id')} "
            f"--field expected_inputs_hash={draft_run.get('inputs_hash')}"
        ) if ready else None,
    }
    print_result(preview)


def handle_tips_session_by_date(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant_id = resolve_restaurant_id(args, state, required=True)

    response = authenticated_request(
        state,
        config,
        "GET",
        f"/api/v1/restaurants/{restaurant_id}/tips/sessions",
        query={"session_date": args.date},
    )
    sessions = (response or {}).get("sessions") if isinstance(response, dict) else None
    if not isinstance(sessions, list) or not sessions:
        raise CliError(f"No tip sessions found for {args.date}.")

    if args.session_name:
        needle = args.session_name.strip().lower()
        matches = [
            s for s in sessions
            if (s.get("session_name") or "").lower() == needle
        ]
        if not matches:
            matches = [
                s for s in sessions
                if needle in (s.get("session_name") or "").lower()
            ]
        if not matches:
            raise CliError(
                f"No session named {args.session_name!r} on {args.date}. "
                f"Available: {[s.get('session_name') for s in sessions]}"
            )
        if len(matches) > 1:
            raise CliError(
                f"Multiple sessions named {args.session_name!r} on {args.date}. "
                "Pass --session-index."
            )
        print_result(matches[0])
        return

    if args.session_index is not None:
        for s in sessions:
            if s.get("session_index") == args.session_index:
                print_result(s)
                return
        raise CliError(
            f"No session with session_index={args.session_index} on {args.date}."
        )

    if len(sessions) == 1:
        print_result(sessions[0])
        return

    raise CliError(
        f"Multiple sessions on {args.date}; pass --session-name or --session-index. "
        f"Found: {[(s.get('session_index'), s.get('session_name')) for s in sessions]}"
    )


def _apply_employee_resolution(
    args: argparse.Namespace,
    spec: ActionSpec,
    state: dict[str, Any],
    config: dict[str, str],
    restaurant_id: str | None,
    body: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Resolve --employee / --invitation flags into path args or body fields."""
    employee_flag = getattr(args, "employee", None)
    invitation_flag = getattr(args, "invitation", None)

    if "employee_id" in spec.path_args:
        provided_id = getattr(args, "employee_id", None)
        if provided_id and employee_flag:
            raise CliError("Pass either EMPLOYEE_ID positional or --employee, not both.")
        if not provided_id:
            if not employee_flag:
                raise CliError(
                    "Missing employee. Pass EMPLOYEE_ID positional or --employee NAME_OR_ID."
                )
            if not restaurant_id:
                raise CliError("Cannot resolve --employee without a restaurant context.")
            resolved = resolve_employee(employee_flag, state, config, restaurant_id)
            args.employee_id = resolved["id"]
    elif employee_flag:
        if not restaurant_id:
            raise CliError("Cannot resolve --employee without a restaurant context.")
        body = dict(body or {})
        if "employee_id" not in body:
            resolved = resolve_employee(employee_flag, state, config, restaurant_id)
            body["employee_id"] = resolved["id"]

    if "invitation_id" in spec.path_args:
        provided_invite = getattr(args, "invitation_id", None)
        if provided_invite and invitation_flag:
            raise CliError("Pass either INVITATION_ID positional or --invitation, not both.")
        if not provided_invite:
            if not invitation_flag:
                raise CliError(
                    "Missing invitation. Pass INVITATION_ID positional or --invitation NAME_OR_EMAIL."
                )
            if not restaurant_id:
                raise CliError("Cannot resolve --invitation without a restaurant context.")
            resolved = resolve_invitation(invitation_flag, state, config, restaurant_id)
            args.invitation_id = resolved["id"]

    return body


def handle_generic_action(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    spec: ActionSpec = args.action_spec
    restaurant_id = resolve_restaurant_id(args, state, spec.requires_restaurant)
    body = merge_body_inputs(args)
    body = _apply_employee_resolution(args, spec, state, config, restaurant_id, body)
    path = build_path(spec, args, restaurant_id)
    query = build_query_params(args)

    if getattr(args, "dry_run", False):
        _handle_dry_run(state, config, spec, path, body, query)
        return

    output_path = getattr(args, "output", None)
    if output_path:
        _, headers, raw_body = authenticated_request(
            state, config, spec.method, path, query=query, body=body, raw=True,
        )
        target = Path(output_path).expanduser()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(_shape_output_bytes(raw_body, headers))
        print_result({"saved_to": str(target), "bytes": target.stat().st_size})
        return

    result = authenticated_request(state, config, spec.method, path, query=query, body=body)
    print_result(result)


def _handle_dry_run(
    state: dict[str, Any],
    config: dict[str, str],
    spec: ActionSpec,
    path: str,
    body: dict[str, Any] | None,
    query: dict[str, Any],
) -> None:
    if spec.section == "workers" and spec.name == "delete":
        record = authenticated_request(state, config, "GET", path)
        employee = (record or {}).get("data") if isinstance(record, dict) else None
        positions = (employee or {}).get("jobPositions") or []
        print_result({
            "dry_run": True,
            "action": "DELETE " + path,
            "employee": {
                "id": (employee or {}).get("id"),
                "fullName": (employee or {}).get("fullName"),
                "status": (employee or {}).get("status"),
                "email": (employee or {}).get("email"),
                "invitationSentAt": (employee or {}).get("invitationSentAt"),
                "positions": [
                    {
                        "jobTypeName": p.get("jobTypeName"),
                        "wageModel": p.get("wageModel"),
                        "wageRate": p.get("wageRate"),
                        "isActive": p.get("isActive"),
                    } for p in positions
                ],
            },
            "note": "No DELETE was sent. Re-run without --dry-run to actually delete.",
        })
        return
    raise CliError(
        f"--dry-run is not supported for `{spec.section} {spec.name}`. "
        "It is currently only implemented for `workers delete`."
    )


def handle_request(args: argparse.Namespace) -> None:
    state = load_state()
    config = resolve_config(state, env_file=args.env_file, require_supabase=False)
    restaurant_id = resolve_restaurant_id(args, state, False)
    if path_requires_restaurant_context(args.path) and not restaurant_id:
        raise CliError(
            "This path requires a restaurant context. Use --restaurant-id or `restaurants select RESTAURANT_ID`."
        )
    path = normalize_path(args.path, restaurant_id)
    body = merge_body_inputs(args)
    query = build_query_params(args)
    if args.output:
        _, _, raw_body = authenticated_request(
            state,
            config,
            args.method,
            path,
            query=query,
            body=body,
            raw=True,
        )
        output_path = Path(args.output).expanduser()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(raw_body)
        print_result({"saved_to": str(output_path), "bytes": len(raw_body)})
        return

    result = authenticated_request(state, config, args.method, path, query=query, body=body)
    print_result(result)


def add_shared_request_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--restaurant-id", help="Override the selected restaurant for this command.")
    parser.add_argument(
        "--employee",
        help="Employee UUID or full name (exact, then case-insensitive, then substring). "
             "Resolves to employee_id for path or body as appropriate.",
    )
    parser.add_argument(
        "--invitation",
        help="Invitation UUID, email, or (partial) full name. Resolves to invitation_id.",
    )
    parser.add_argument(
        "--query",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Query parameter. Repeat as needed.",
    )
    parser.add_argument(
        "--field",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="JSON body field. Repeat as needed. Values are parsed as JSON/bool/number when possible.",
    )
    parser.add_argument("--json-body", help="Raw JSON object string to merge into the request body.")
    parser.add_argument("--json-file", help="Path to a JSON file to merge into the request body.")
    parser.add_argument("--env-file", help="Optional env file with NEXT_PUBLIC_* values.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview without calling the destructive endpoint. Currently supported for `workers delete`.",
    )
    parser.add_argument(
        "--output",
        help="Write the raw response body to this path instead of printing. "
             "Use for binary downloads (xlsx/csv) or to archive a JSON snapshot.",
    )


def _resolve_cli_version() -> str:
    """Best-effort version lookup. Falls back gracefully if the CLI is being
    invoked from a source checkout (no installed distribution metadata)."""
    try:
        from importlib.metadata import PackageNotFoundError, version as _pkg_version
        return _pkg_version("yumyum-owner-cli")
    except Exception:
        return "0.0.0+source"


def handle_version(_args: argparse.Namespace) -> None:
    print_result({
        "name": "yumyum-owner-cli",
        "version": _resolve_cli_version(),
        "python": sys.version.split()[0],
    })


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="owner-cli",
        description=(
            "Owner/admin CLI for the YumYum system. Common workflows have dedicated commands, "
            "and any other endpoint can be exercised through `request`."
        ),
    )
    subparsers = parser.add_subparsers(dest="command")
    subparsers.required = True

    version_parser = subparsers.add_parser(
        "version",
        help="Print the CLI version and Python runtime.",
    )
    version_parser.set_defaults(handler=handle_version)

    config_parser = subparsers.add_parser("config", help="Manage CLI configuration.")
    config_subparsers = config_parser.add_subparsers(dest="config_command")
    config_subparsers.required = True

    config_import = config_subparsers.add_parser("import-env", help="Import API + Supabase config from env vars or an env file.")
    config_import.add_argument("--env-file", help="Path to an env file such as /tmp/yumyum-frontend.env.")
    config_import.add_argument("--api-url")
    config_import.add_argument("--supabase-url")
    config_import.add_argument("--supabase-anon-key")
    config_import.set_defaults(handler=handle_config_import_env)

    config_set = config_subparsers.add_parser(
        "set",
        help="Save API and Supabase config directly without using an env file.",
    )
    config_set.add_argument("--api-url", required=True)
    config_set.add_argument("--supabase-url", required=True)
    config_set.add_argument("--supabase-anon-key", required=True)
    config_set.set_defaults(handler=handle_config_import_env)

    config_show = config_subparsers.add_parser("show", help="Show the effective CLI configuration.")
    config_show.add_argument("--env-file")
    config_show.add_argument("--api-url")
    config_show.add_argument("--supabase-url")
    config_show.add_argument("--supabase-anon-key")
    config_show.set_defaults(handler=handle_config_show)

    auth_parser = subparsers.add_parser("auth", help="Log in, inspect the current session, or log out.")
    auth_subparsers = auth_parser.add_subparsers(dest="auth_command")
    auth_subparsers.required = True

    auth_login = auth_subparsers.add_parser("login", help="Log in with Supabase email/password auth.")
    auth_login.add_argument("--email")
    auth_login.add_argument("--password")
    auth_login.add_argument("--env-file")
    auth_login.add_argument("--api-url")
    auth_login.add_argument("--supabase-url")
    auth_login.add_argument("--supabase-anon-key")
    auth_login.set_defaults(handler=handle_auth_login)

    auth_assume = auth_subparsers.add_parser(
        "assume",
        help="Create a local owner/admin session for an existing Supabase user without changing their password.",
    )
    auth_assume.add_argument("--user-id", help="Supabase auth user ID to assume.")
    auth_assume.add_argument("--email", help="Supabase auth email to look up and assume.")
    auth_assume.add_argument("--full-name", help="Optional full name override stored in local session metadata.")
    auth_assume.add_argument("--expires-in", default=3600, type=int, help="Local access token lifetime in seconds.")
    auth_assume.add_argument("--env-file")
    auth_assume.add_argument("--api-url")
    auth_assume.add_argument("--supabase-url")
    auth_assume.add_argument("--supabase-anon-key")
    auth_assume.add_argument("--supabase-service-role-key")
    auth_assume.add_argument("--supabase-jwt-secret")
    auth_assume.set_defaults(handler=handle_auth_assume)

    auth_refresh = auth_subparsers.add_parser("refresh", help="Refresh the stored session.")
    auth_refresh.add_argument("--env-file")
    auth_refresh.set_defaults(handler=handle_auth_refresh)

    auth_logout = auth_subparsers.add_parser("logout", help="Clear the stored session.")
    auth_logout.set_defaults(handler=handle_auth_logout)

    auth_whoami = auth_subparsers.add_parser("whoami", help="Show the current profile and restaurant roles.")
    auth_whoami.add_argument("--env-file")
    auth_whoami.set_defaults(handler=handle_auth_whoami)

    section_parsers: dict[str, argparse._SubParsersAction] = {}

    restaurants_parser = subparsers.add_parser("restaurants", help="Restaurant actions and context helpers.")
    restaurants_subparsers = restaurants_parser.add_subparsers(dest="restaurants_command")
    restaurants_subparsers.required = True
    section_parsers["restaurants"] = restaurants_subparsers

    restaurants_select = restaurants_subparsers.add_parser("select", help="Persist a default restaurant for later commands.")
    restaurants_select.add_argument("restaurant_id")
    restaurants_select.add_argument("--env-file")
    restaurants_select.set_defaults(handler=handle_restaurant_select)

    restaurants_current = restaurants_subparsers.add_parser("current", help="Show the currently selected restaurant.")
    restaurants_current.add_argument("--env-file")
    restaurants_current.set_defaults(handler=handle_restaurant_current)

    operations_parser = subparsers.add_parser("operations", help="List the dedicated action commands.")
    operations_parser.add_argument("--section", help="Optional section filter such as workers or wages.")
    operations_parser.set_defaults(handler=handle_operations_list)

    request_parser = subparsers.add_parser("request", help="Make an authenticated request to any backend endpoint.")
    request_parser.add_argument("method", help="HTTP method, for example GET or POST.")
    request_parser.add_argument("path", help="Absolute API path. Use :restaurant to inject the selected restaurant.")
    add_shared_request_options(request_parser)
    request_parser.set_defaults(handler=handle_request)

    for spec in ACTION_SPECS:
        if spec.section not in section_parsers:
            section_parser = subparsers.add_parser(spec.section, help=f"{spec.section} actions.")
            section_subparsers = section_parser.add_subparsers(dest=f"{spec.section}_command")
            section_subparsers.required = True
            section_parsers[spec.section] = section_subparsers

        action_parser = section_parsers[spec.section].add_parser(
            spec.name,
            help=spec.description or f"{spec.method} {spec.path_template}",
        )
        for arg_name in spec.path_args:
            if arg_name in ("employee_id", "invitation_id"):
                action_parser.add_argument(arg_name, nargs="?", default=None)
            else:
                action_parser.add_argument(arg_name)
        add_shared_request_options(action_parser)
        action_parser.set_defaults(handler=handle_generic_action, action_spec=spec)

    workers_find = section_parsers["workers"].add_parser(
        "find",
        help="Resolve an employee UUID or full name (exact → case-insensitive → substring) to a full record.",
    )
    workers_find.add_argument("identifier", help="Employee UUID or (partial) full name.")
    workers_find.add_argument("--restaurant-id")
    workers_find.add_argument("--env-file")
    workers_find.set_defaults(handler=handle_workers_find)

    workers_find_invite = section_parsers["workers"].add_parser(
        "find-invite",
        help="Resolve an invitation UUID, email, or (partial) full name to a pending invitation record.",
    )
    workers_find_invite.add_argument("identifier", help="Invitation UUID, email, or (partial) full name.")
    workers_find_invite.add_argument("--restaurant-id")
    workers_find_invite.add_argument("--env-file")
    workers_find_invite.set_defaults(handler=handle_workers_find_invite)

    daily_parser = subparsers.add_parser("daily", help="Daily operations rollup.")
    daily_subparsers = daily_parser.add_subparsers(dest="daily_command")
    daily_subparsers.required = True
    daily_summary = daily_subparsers.add_parser(
        "summary",
        help="Same-day attendance + tip-session rollup for a given date.",
    )
    daily_summary.add_argument("--date", required=True, help="Date in restaurant-local YYYY-MM-DD.")
    daily_summary.add_argument("--restaurant-id")
    daily_summary.add_argument("--env-file")
    daily_summary.set_defaults(handler=handle_daily_summary)

    wages_finalize_preview = section_parsers["wages"].add_parser(
        "finalize-preview",
        help="Compose payroll-overview into a finalize-readiness summary without mutating anything.",
    )
    wages_finalize_preview.add_argument("--period-start", required=True, help="Period start (YYYY-MM-DD).")
    wages_finalize_preview.add_argument("--period-end", required=True, help="Period end (YYYY-MM-DD).")
    wages_finalize_preview.add_argument("--restaurant-id")
    wages_finalize_preview.add_argument("--env-file")
    wages_finalize_preview.set_defaults(handler=handle_wages_finalize_preview)

    tips_session_by_date = section_parsers["tips"].add_parser(
        "session-by-date",
        help="Resolve a tip session by date (plus optional --session-name or --session-index) to a full record.",
    )
    tips_session_by_date.add_argument("--date", required=True, help="Session date (YYYY-MM-DD).")
    tips_session_by_date.add_argument("--session-name", help="Case-insensitive match on session_name.")
    tips_session_by_date.add_argument("--session-index", type=int, help="Exact match on session_index.")
    tips_session_by_date.add_argument("--restaurant-id")
    tips_session_by_date.add_argument("--env-file")
    tips_session_by_date.set_defaults(handler=handle_tips_session_by_date)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        args.handler(args)
        return 0
    except HttpRequestError as exc:
        print_result(
            {
                "error": str(exc),
                "status_code": exc.status_code,
                "payload": exc.payload,
            }
        )
        return 1
    except CliError as exc:
        print(json.dumps({"error": str(exc)}, indent=2, ensure_ascii=False))
        return 1
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
